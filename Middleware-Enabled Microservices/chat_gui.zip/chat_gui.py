import tkinter as tk
from tkinter import scrolledtext
import pika
import threading

# RabbitMQ setup
RABBITMQ_HOST = 'localhost'

class ChatApp:
    def __init__(self, root):
        self.root = root
        self.root.title("RabbitMQ Chat Application")

        # Username entry
        self.label_username = tk.Label(root, text="Enter your username:")
        self.label_username.pack(pady=10)

        self.entry_username = tk.Entry(root)
        self.entry_username.pack(pady=5)

        self.button_set_username = tk.Button(root, text="Set Username", command=self.set_username)
        self.button_set_username.pack(pady=5)

        # Message display area (scrollable)
        self.text_area = scrolledtext.ScrolledText(root, wrap=tk.WORD, state='disabled', width=50, height=15)
        self.text_area.pack(pady=10)

        # Add label for message entry field
        self.label_message = tk.Label(root, text="Write your message:")
        self.label_message.pack(pady=5)

        # Message input field
        self.entry_message = tk.Entry(root, state='disabled')
        self.entry_message.pack(pady=5)

        self.button_send = tk.Button(root, text="Send", state='disabled', command=self.send_message)
        self.button_send.pack(pady=5)

        self.username = None
        self.connection = None
        self.channel = None

    def set_username(self):
        self.username = self.entry_username.get().strip()
        if self.username:
            self.entry_username.config(state='disabled')
            self.button_set_username.config(state='disabled')
            self.entry_message.config(state='normal')
            self.button_send.config(state='normal')
            threading.Thread(target=self.setup_rabbitmq, daemon=True).start()

    def setup_rabbitmq(self):
        self.connection = pika.BlockingConnection(pika.ConnectionParameters(RABBITMQ_HOST))
        self.channel = self.connection.channel()
        self.channel.exchange_declare(exchange='chat_room', exchange_type='fanout')
        result = self.channel.queue_declare(queue='', exclusive=True)
        queue_name = result.method.queue
        self.channel.queue_bind(exchange='chat_room', queue=queue_name)
        self.channel.basic_consume(queue=queue_name, on_message_callback=self.receive_message, auto_ack=True)
        self.channel.start_consuming()

    def receive_message(self, ch, method, properties, body):
        message = body.decode()
        # Update text area in a thread-safe way
        self.text_area.config(state='normal')
        self.text_area.insert(tk.END, f"{message}\n")
        self.text_area.yview(tk.END)
        self.text_area.config(state='disabled')

    def send_message(self):
        message = self.entry_message.get().strip()
        if message and self.channel:
            full_message = f"{self.username}: {message}"
            self.channel.basic_publish(exchange='chat_room', routing_key='', body=full_message)
            self.entry_message.delete(0, tk.END)

# Create the main window
root = tk.Tk()
app = ChatApp(root)
root.mainloop()

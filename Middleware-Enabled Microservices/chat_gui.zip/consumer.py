import pika

# Replace with your RabbitMQ server host if different
RABBITMQ_HOST = 'localhost'

# Callback function to handle received messages
def receive_messages(ch, method, properties, body):
    print(f"Received: {body.decode()}")

# Establish connection to RabbitMQ server
connection = pika.BlockingConnection(pika.ConnectionParameters(RABBITMQ_HOST))
channel = connection.channel()

# Declare the exchange
channel.exchange_declare(exchange='chat_room', exchange_type='fanout')

# Declare a temporary queue to receive messages from the exchange
result = channel.queue_declare(queue='', exclusive=True)
queue_name = result.method.queue

# Bind the queue to the exchange
channel.queue_bind(exchange='chat_room', queue=queue_name)

print("Waiting for messages...")

# Start consuming messages
channel.basic_consume(queue=queue_name, on_message_callback=receive_messages, auto_ack=True)
channel.start_consuming()

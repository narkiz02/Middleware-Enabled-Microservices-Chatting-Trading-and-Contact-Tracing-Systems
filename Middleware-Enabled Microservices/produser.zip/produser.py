import pika

# Replace with your RabbitMQ server host if different
RABBITMQ_HOST = 'localhost'

# Establish connection to RabbitMQ server
connection = pika.BlockingConnection(pika.ConnectionParameters(RABBITMQ_HOST))
channel = connection.channel()

# Declare the exchange
channel.exchange_declare(exchange='chat_room', exchange_type='fanout')

print("Enter messages to send. Type 'exit' to quit.")
while True:
    message = input("Message: ")
    if message.lower() == 'exit':
        break
    # Publish message to the exchange
    channel.basic_publish(exchange='chat_room', routing_key='', body=message)

connection.close()


import tkinter as tk
from tkinter import messagebox

class ContactTracingApp:
    def __init__(self, master):
        self.master = master
        master.title("Contact Tracing System")

        self.grid_size = 10  # Configurable size, initially set to 10
        self.cells = [[None for _ in range(self.grid_size)] for _ in range(self.grid_size)]

        # Labels and Entry for querying contacts
        self.label = tk.Label(master, text="Enter Person Identifier:")
        self.identifier_entry = tk.Entry(master)
        self.query_button = tk.Button(master, text="Query Contacts", command=self.query_contacts)
        self.result_label = tk.Label(master, text="")

        # Labels and Entry for grid size
        self.size_label = tk.Label(master, text="Select Grid Size:")
        self.size_entry = tk.Entry(master)
        self.size_button = tk.Button(master, text="Set Size", command=self.set_board_size)

        self.create_grid()  # Create the initial grid

        # Positioning the components in the grid
        self.position_components()

    def create_grid(self):
        # Clear previous grid if exists
        for widget in self.master.grid_slaves():
            widget.destroy()

        # Recreate grid for the environment
        for x in range(self.grid_size):
            for y in range(self.grid_size):
                cell = tk.Label(self.master, width=4, height=2, borderwidth=1, relief="solid")
                cell.grid(row=x, column=y)
                self.cells[x][y] = cell

    def position_components(self):
        # Positioning all components in the grid
        self.label.grid(row=self.grid_size, column=0, columnspan=2)
        self.identifier_entry.grid(row=self.grid_size, column=2)
        self.query_button.grid(row=self.grid_size, column=3)
        self.result_label.grid(row=self.grid_size + 1, column=0, columnspan=4)

        self.size_label.grid(row=self.grid_size + 2, column=0)
        self.size_entry.grid(row=self.grid_size + 2, column=1)
        self.size_button.grid(row=self.grid_size + 2, column=2)

    def set_board_size(self):
        new_size = int(self.size_entry.get())
        if new_size < 1 or new_size > 1000:  # Set limits for grid size
            messagebox.showerror("Invalid Size", "Please enter a size between 1 and 1000.")
            return
        self.grid_size = new_size
        self.create_grid()  # Recreate the grid based on new size
        self.position_components()  # Reposition components to accommodate new grid size

    def query_contacts(self):
        identifier = self.identifier_entry.get()
        contacts = self.get_contacts(identifier)  # Replace with actual RabbitMQ logic
        if contacts is not None:
            self.result_label.config(text=f"Contacts for {identifier}: {', '.join(contacts)}")
        else:
            self.result_label.config(text=f"No contacts found for {identifier}.")

    def get_contacts(self, identifier):
        # Implement the RabbitMQ logic to get contacts
        return ["Person 2", "Person 3"]  # Replace with actual contact data

if __name__ == "__main__":
    root = tk.Tk()
    app = ContactTracingApp(root)
    root.mainloop()


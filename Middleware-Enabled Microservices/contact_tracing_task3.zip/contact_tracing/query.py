def query_contacts(person_id):
    # This function is a placeholder for querying contacts
    print(f"Querying contacts for Person {person_id}...")
    # Simulate contact data
    contacts = ["Person 2", "Person 3"]
    print(f"Contacts for Person {person_id}: {contacts}")

if __name__ == "__main__":
    query_contacts("1")  # Replace "1" with the person ID you want to query

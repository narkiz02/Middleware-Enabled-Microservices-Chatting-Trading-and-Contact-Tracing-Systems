import pika
import random
import time

def publish_position(person_id):
    # Connect to RabbitMQ server
    connection = pika.BlockingConnection(pika.ConnectionParameters('localhost'))
    channel = connection.channel()

    # Declare the exchange as durable
    channel.exchange_declare(exchange='position', exchange_type='topic', durable=True)

    while True:
        # Simulate random position (for example, coordinates)
        position = f"({random.randint(0, 10)}, {random.randint(0, 10)})"
        message = f"Person {person_id} is at position {position}"
        # Publish the message to the exchange
        channel.basic_publish(exchange='position', routing_key='person.position', body=message)
        print(f"Published: {message}")
        time.sleep(5)  # Sleep for 5 seconds before publishing again

    connection.close()

if __name__ == "__main__":
    publish_position("1")  # Replace "1" with the person ID as needed


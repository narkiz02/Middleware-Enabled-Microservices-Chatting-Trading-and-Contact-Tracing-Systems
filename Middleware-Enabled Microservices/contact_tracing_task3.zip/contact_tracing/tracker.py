import pika

def track_positions():
    # Connect to RabbitMQ server
    connection = pika.BlockingConnection(pika.ConnectionParameters('localhost'))
    channel = connection.channel()

    # Declare the exchange as durable
    channel.exchange_declare(exchange='position', exchange_type='topic', durable=True)

    # Create a queue for tracking positions
    result = channel.queue_declare(queue='', exclusive=True)
    queue_name = result.method.queue

    # Bind the queue to the exchange
    channel.queue_bind(exchange='position', queue=queue_name, routing_key='person.position')

    print('Waiting for position updates...')

    def callback(ch, method, properties, body):
        print(f"Received {body.decode()}")

    channel.basic_consume(queue=queue_name, on_message_callback=callback, auto_ack=True)
    channel.start_consuming()

if __name__ == "__main__":
    track_positions()


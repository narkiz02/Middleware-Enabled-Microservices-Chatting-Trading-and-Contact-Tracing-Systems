import sys
import pika
import json
import tkinter as tk
from threading import Thread

class PriceDisplay:
    def __init__(self, middleware_endpoint):
        # Establish connection to RabbitMQ
        self.connection = pika.BlockingConnection(
            pika.ConnectionParameters(host=middleware_endpoint)
        )
        self.channel = self.connection.channel()
        # Declare 'trades' exchange
        self.channel.exchange_declare(exchange='trades', exchange_type='fanout')
        # Create a temporary queue for this consumer 
        result = self.channel.queue_declare(queue='', exclusive=True)
        self.queue_name = result.method.queue
        # Bind the queue to the 'trades' exchange 
        self.channel.queue_bind(exchange='trades', queue=self.queue_name)

        # Setup GUI
        self.root = tk.Tk()
        self.root.title("XYZ Corp Stock Price")
        self.price_label = tk.Label(self.root, text="Waiting for trades...", font=("Arial", 24))
        self.price_label.pack(padx=20, pady=20)

    def start(self):
        # Start consuming trades in a seperate thread 
        thread = Thread(target=self.consume_trades)
        thread.start()
        # Start the GUI main loop
        self.root.mainloop()

    def consume_trades(self):
        # Set up message consumption from the queue
        self.channel.basic_consume(
            queue=self.queue_name, on_message_callback=self.update_price, auto_ack=True
        )
        self.channel.start_consuming()

    def update_price(self, ch, method, properties, body):
        # Process imcoming trade data
        trade = json.loads(body)
        # Schedule the GUI update in the main thread 
        self.root.after(0, self.update_label, trade['price'])

    def update_label(self, price):
        # Update the price display in the GUI
        self.price_label.config(text=f"XYZ Corp: ${price:.2f}")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python price_display.py <middleware_endpoint>")
        sys.exit(1)

    middleware_endpoint = sys.argv[1]
    display = PriceDisplay(middleware_endpoint)
    display.start()

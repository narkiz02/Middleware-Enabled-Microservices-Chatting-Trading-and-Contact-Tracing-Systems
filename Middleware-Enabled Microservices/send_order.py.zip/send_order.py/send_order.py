# Import necessary libraries for system operations, messaging, and data handling
import sys
import pika
import json

# Define a function to process and transmit trade information
def send_order(username, middleware_endpoint, side, quantity, price):
    try:
        # Establish a connection to the message middleware
        connection = pika.BlockingConnection(
            pika.ConnectionParameters(host=middleware_endpoint)
        )
        channel = connection.channel()
# Declare an exchange for broadcasting trade information
        channel.exchange_declare(exchange='orders', exchange_type='fanout')
        # Prepare the order details
        order = {
            'username': username,
            'side': side,
            'quantity': quantity,
            'price': price
        }
        # Publish the order to the exchange
        channel.basic_publish(exchange='orders', routing_key='', body=json.dumps(order))
        print(f"Order sent: {order}")
        # Close the connection to the middleware
        connection.close()
    except Exception as e:
        print(f"Error: {str(e)}")
# Main execution block
if __name__ == "__main__":
    # Verify the correct number of command-line arguments
    if len(sys.argv) != 6:
        print("Usage: python send_order.py <username> <middleware_endpoint> <BUY/SELL> <quantity> <price>")
        sys.exit(1)
    # Extract command-line arguments
    username = sys.argv[1]
    middleware_endpoint = sys.argv[2]
    side = sys.argv[3]
    quantity = int(sys.argv[4])
    price = float(sys.argv[5])
    # Call the function to process the transaction
    send_order(username, middleware_endpoint, side, quantity, price)

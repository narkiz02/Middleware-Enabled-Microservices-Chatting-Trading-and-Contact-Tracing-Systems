# Import necessary libraries
import sys
import pika
import json
from collections import defaultdict

class Exchange:
    def __init__(self, middleware_endpoint):
        # Establish connection to RabbitMQ
        self.connection = pika.BlockingConnection(
            pika.ConnectionParameters(host=middleware_endpoint)
        )
        self.channel = self.connection.channel()
        # Declare exchanges for orders and trades
        self.channel.exchange_declare(exchange='orders', exchange_type='fanout')
        self.channel.exchange_declare(exchange='trades', exchange_type='fanout')
        # Declare and bind queue for orders
        self.channel.queue_declare(queue='orders_queue')
        self.channel.queue_bind(exchange='orders', queue='orders_queue')
        # Initialize order book
        self.order_book = defaultdict(lambda: {'BUY': [], 'SELL': []})

    def start(self):
        # Start consuming messages from the order queue
        self.channel.basic_consume(
            queue='orders_queue', on_message_callback=self.process_order, auto_ack=True
        )
        print("Exchange is running. To exit press CTRL+C")
        self.channel.start_consuming()

    def process_order(self, ch, method, properties, body):
        # Process incoming order
        order = json.loads(body)
        stock = 'XYZ'  # For now, we only have one stock
        if self.match_order(stock, order):
            print(f"Order matched: {order}")
        else:
            self.add_to_order_book(stock, order)
            print(f"Order added to book: {order}")

    def match_order(self, stock, order):
        # Try to match the order with existing orders
        opposite_side = 'SELL' if order['side'] == 'BUY' else 'BUY'
        for existing_order in self.order_book[stock][opposite_side]:
            if self.is_price_acceptable(order, existing_order):
                self.execute_trade(stock, order, existing_order)
                self.order_book[stock][opposite_side].remove(existing_order)
                return True
        return False

    def is_price_acceptable(self, order1, order2):
        # Check if the price is acceptable for a trade
        if order1['side'] == 'BUY':
            return order1['price'] >= order2['price']
        else:
            return order1['price'] <= order2['price']

    def execute_trade(self, stock, order1, order2):
        # Execute a trade between two matching orders
        trade_price = (order1['price'] + order2['price']) / 2
        trade = {
            'stock': stock,
            'price': trade_price,
            'quantity': min(order1['quantity'], order2['quantity']),
            'buyer': order1['username'] if order1['side'] == 'BUY' else order2['username'],
            'seller': order1['username'] if order1['side'] == 'SELL' else order2['username']
        }
        # Publish the trade to the trades exchange
        self.channel.basic_publish(exchange='trades', routing_key='', body=json.dumps(trade))
        print(f"Trade executed: {trade}")

    def add_to_order_book(self, stock, order):
        # Add order to the order book and sort
        self.order_book[stock][order['side']].append(order)
        self.order_book[stock][order['side']].sort(
            key=lambda x: x['price'], reverse=(order['side'] == 'BUY')
        )

if __name__ == "__main__":
    # Check for correct command-line usage
    if len(sys.argv) != 2:
        print("Usage: python consumer.py <middleware_endpoint>")
        sys.exit(1)
    # Get middleware endpoint from command-line argument
    middleware_endpoint = sys.argv[1]
    # Create and start exchange
    exchange = Exchange(middleware_endpoint)
    exchange.start()
